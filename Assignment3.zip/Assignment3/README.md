Bathroom App: https://bathroom-finder-app.herokuapp.com/
Github: https://github.com/LiangJoshua/Bathroom-Finder